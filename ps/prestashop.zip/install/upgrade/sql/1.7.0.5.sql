/* PHP:ps_update_tabs(); */;
ALTER TABLE `PREFIX_currency` MODIFY `name` varchar(64) NOT NULL;
